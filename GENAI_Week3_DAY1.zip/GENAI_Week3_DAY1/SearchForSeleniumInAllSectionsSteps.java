package automation.tests.steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;

import automation.tests.pages.SearchForSeleniumInAllSectionsPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class SearchForSeleniumInAllSectionsSteps {

    private WebDriver driver;
    private SearchForSeleniumInAllSectionsPage page;

    @Before
    public void setUp() {
        // Assuming chromedriver is available in the system PATH
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        page = new SearchForSeleniumInAllSectionsPage(driver);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Given("the user is on the Amazon homepage")
    public void the_user_is_on_the_amazon_homepage() {
        driver.get("https://www.amazon.com");
    }

    @When("the user enters {string} in the search field")
    public void the_user_enters_in_the_search_field(String term) {
        page.enterSearchTerm(term);
        // Verify the term is displayed in the field
        Assert.assertEquals(page.getSearchFieldValue(), term, "Search term not entered correctly");
    }

    @And("the user verifies the search category dropdown is set to {string}")
    public void the_user_verifies_the_search_category_dropdown_is_set_to(String expectedOption) {
        String actualOption = page.getSelectedCategory();
        Assert.assertEquals(actualOption, expectedOption, "Dropdown category mismatch");
    }

    @And("the user clicks the Go button")
    public void the_user_clicks_the_go_button() {
        page.clickSearchButton();
    }

    @Then("the search results page URL should contain {string}")
    public void the_search_results_page_url_should_contain(String expectedFragment) {
        Assert.assertTrue(page.getCurrentUrl().contains(expectedFragment),
                "URL does not contain expected fragment: " + expectedFragment);
    }

    @And("the page title should be {string}")
    public void the_page_title_should_be(String expectedTitle) {
        Assert.assertEquals(page.getTitle(), expectedTitle, "Page title mismatch");
    }

    @And("the results heading should display results for {string}")
    public void the_results_heading_should_display_results_for(String term) {
        Assert.assertTrue(page.isResultsHeadingDisplayed(term),
                "Results heading does not display expected term: " + term);
    }
}
